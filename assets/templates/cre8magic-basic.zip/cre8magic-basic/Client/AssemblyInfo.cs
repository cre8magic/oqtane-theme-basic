using System.Resources;
using Microsoft.Extensions.Localization;

[assembly: RootNamespace("[Owner].Cre8magic.Theme.[Theme].Client")]
